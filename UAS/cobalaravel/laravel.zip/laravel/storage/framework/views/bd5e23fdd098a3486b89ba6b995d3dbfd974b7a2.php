<?php $__env->startSection('container'); ?>
<div class="container">
  <img src="img/logobbs.png" class="rounded mx-auto d-block mt-2" alt="" width="100px">
  <div class="row">
    <h4 class="text-center mt-2">Cek Kelulusan SMA Babussalam</h4>
    <div class="table mt-4">
      <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p>Nama : <?php echo e($data["Nama_Lengkap"]); ?></p>
        <p>Jenis Kelamin : <?php echo e($data["Jenis_Kelamin"]); ?></p>
        <p>NIS : <?php echo e($data["NISN"]); ?></p>
        <p>Keterangan : <?php echo e($data["Keterangan"]); ?></p>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="d-flex justify-content-center">
      <a href="/" class="btn btn-success">Kembali</a>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\College\Materi Perkuliahan\Semester 4\Pweb\Praktek\UAS\cobalaravel\laravel-coba\resources\views/hasil.blade.php ENDPATH**/ ?>